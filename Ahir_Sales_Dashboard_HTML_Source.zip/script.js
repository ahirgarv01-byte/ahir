const demo=[
{Order_Date:"2023-01-15",Net_Sales:12500,Quantity:25,Category:"Electronics",Product:"Smart Sensor",Region:"North",Country:"India",Order_ID:"O1001",Payment_Method:"Card"},
{Order_Date:"2023-04-20",Net_Sales:18200,Quantity:40,Category:"Electronics",Product:"Smart Sensor",Region:"West",Country:"India",Order_ID:"O1002",Payment_Method:"UPI"},
{Order_Date:"2024-02-10",Net_Sales:22100,Quantity:32,Category:"Furniture",Product:"Office Chair",Region:"South",Country:"Malawi",Order_ID:"O1003",Payment_Method:"Cash"},
{Order_Date:"2024-06-11",Net_Sales:15400,Quantity:55,Category:"Accessories",Product:"USB Hub",Region:"East",Country:"UAE",Order_ID:"O1004",Payment_Method:"Card"},
{Order_Date:"2025-03-05",Net_Sales:29800,Quantity:48,Category:"Electronics",Product:"Router",Region:"West",Country:"India",Order_ID:"O1005",Payment_Method:"UPI"},
{Order_Date:"2025-09-18",Net_Sales:9900,Quantity:22,Category:"Furniture",Product:"Office Chair",Region:"North",Country:"Malawi",Order_ID:"O1006",Payment_Method:"Cash"},
{Order_Date:"2025-11-02",Net_Sales:17400,Quantity:60,Category:"Accessories",Product:"USB Hub",Region:"South",Country:"UAE",Order_ID:"O1007",Payment_Method:"Card"}
];
let rows=demo, charts={};
const $=id=>document.getElementById(id);
const fmt=n=>Number(n||0).toLocaleString(undefined,{maximumFractionDigits:2});
function val(r,k){return r[k]??r[k.toLowerCase()]??""}
function num(r,k){return Number(String(val(r,k)).replace(/[^0-9.-]/g,""))||0}
function unique(k){return [...new Set(rows.map(r=>String(val(r,k))).filter(Boolean))].sort()}
function fill(id,k){const s=$(id),old=s.value;s.innerHTML='<option value="">All '+(k==='Payment_Method'?'methods':k.toLowerCase()+'s')+'</option>';unique(k).forEach(v=>{let o=document.createElement('option');o.value=v;o.textContent=v;s.appendChild(o)});s.value=old}
function refreshFilters(){fill('yearFilter','Year');fill('regionFilter','Region');fill('categoryFilter','Category');fill('countryFilter','Country');fill('paymentFilter','Payment_Method')}
function filtered(){return rows.filter(r=>{let date=new Date(val(r,'Order_Date')),y=Number.isNaN(date.getTime())?'':String(date.getFullYear());return (!$('yearFilter').value||y===$('yearFilter').value)&&(!$('regionFilter').value||val(r,'Region')===$('regionFilter').value)&&(!$('categoryFilter').value||val(r,'Category')===$('categoryFilter').value)&&(!$('countryFilter').value||val(r,'Country')===$('countryFilter').value)&&(!$('paymentFilter').value||val(r,'Payment_Method')===$('paymentFilter').value)})}
function group(data,key,measure,mode='sum'){let m={};data.forEach(r=>{let k=String(val(r,key)||'Unknown');m[k]=(m[k]||0)+(mode==='count'? (val(r,measure)!==''?1:0):num(r,measure))});return Object.entries(m).sort((a,b)=>b[1]-a[1])}
function draw(id,type,labels,data,label,horizontal=false){if(charts[id])charts[id].destroy();charts[id]=new Chart($(id),{type,data:{labels,datasets:[{label,data,backgroundColor:type==='line'?'rgba(42,128,199,.18)':'rgba(42,128,199,.75)',borderColor:'#2a80c7',borderWidth:2,fill:type==='line',tension:.3}]},options:{responsive:true,maintainAspectRatio:false,indexAxis:horizontal?'y':'x',plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,grid:{color:'#edf1f6'}},x:{grid:{display:false}}}}})}
function update(){let d=filtered();$('totalSales').textContent=fmt(d.reduce((s,r)=>s+num(r,'Net_Sales'),0));$('totalQty').textContent=fmt(d.reduce((s,r)=>s+num(r,'Quantity'),0));$('totalOrders').textContent=new Set(d.map(r=>val(r,'Order_ID')).filter(Boolean)).size.toLocaleString();$('totalCountries').textContent=new Set(d.map(r=>val(r,'Country')).filter(Boolean)).size;
let years={};d.forEach(r=>{let dt=new Date(val(r,'Order_Date'));if(!Number.isNaN(dt.getTime())){let y=dt.getFullYear();years[y]=(years[y]||0)+num(r,'Net_Sales)}});let t=Object.entries(years).sort((a,b)=>a[0]-b[0]);draw('trendChart','line',t.map(x=>x[0]),t.map(x=>x[1]),'Net Sales');
let c=group(d,'Category','Net_Sales');draw('categoryChart','bar',c.map(x=>x[0]),c.map(x=>x[1]),'Net Sales');
let p=group(d,'Product','Net_Sales').slice(0,10);draw('productChart','bar',p.map(x=>x[0]),p.map(x=>x[1]),'Net Sales',true);
let r=group(d,'Region','Net_Sales');draw('regionChart','bar',r.map(x=>x[0]),r.map(x=>x[1]),'Net Sales');
let q=group(d,'Category','Quantity');draw('quantityChart','bar',q.map(x=>x[0]),q.map(x=>x[1]),'Quantity');
let pay=group(d,'Payment_Method','Payment_Method','count');draw('paymentChart','bar',pay.map(x=>x[0]),pay.map(x=>x[1]),'Payment entries',true);
let co=group(d,'Country','Net_Sales');draw('countryChart','bar',co.map(x=>x[0]),co.map(x=>x[1]),'Net Sales',true)}
['yearFilter','regionFilter','categoryFilter','countryFilter','paymentFilter'].forEach(id=>$(id).addEventListener('change',update));
$('resetBtn').onclick=()=>{['yearFilter','regionFilter','categoryFilter','countryFilter','paymentFilter'].forEach(id=>$(id).value='');update()};
function parseCSV(text){let lines=text.trim().split(/\r?\n/),headers=lines.shift().split(',').map(x=>x.trim().replace(/^"|"$/g,''));return lines.map(line=>{let vals=line.match(/("([^"]|"")*"|[^,]*)(,|$)/g)||[];vals=vals.map(x=>x.replace(/,$/,'').trim().replace(/^"|"$/g,'').replace(/""/g,'"'));let o={};headers.forEach((h,i)=>o[h]=vals[i]??'');return o})}
$('csvFile').addEventListener('change',async e=>{let f=e.target.files[0];if(!f)return;let txt=await f.text();let data=parseCSV(txt);if(!data.length){alert('Could not read CSV.');return}rows=data;$('dataNotice').textContent='Loaded '+rows.length.toLocaleString()+' CSV records. Charts now use your imported data.';refreshFilters();update()});
refreshFilters();update();